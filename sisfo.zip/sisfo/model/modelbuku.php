<?php
include_once("./model/db.php");

function read_all_buku(){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_buku ");
    $data = mysqli_fetch_all($query,MYSQLI_ASSOC);
    return $data;
}

function read_available_buku(){
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "SELECT * FROM tbl_buku WHERE status='tersedia'");
    $data = mysqli_fetch_all($query, MYSQLI_ASSOC);
    return $data;
}


function read_single_buku($kode_buku){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_buku where kode_buku='$kode_buku'");
    $data = mysqli_fetch_array($query);
    return $data;
}

function save_new_buku($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit, $status){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_buku where kode_buku='$kode_buku'");
    if(mysqli_num_rows($query) > 0){
        return false;
    }

    $query = mysqli_query($koneksi, "insert into tbl_buku (kode_buku, isbn, judul, pengarang, tahun, penerbit, status)
    values('$kode_buku', '$isbn', '$judul', '$pengarang', '$tahun', '$penerbit', '$status')");
    if($query){
        return true;
    }else{
        return false;
    }
}

function save_edit_buku($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit, $status, $kodebuku_lama){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "update tbl_buku set kode_buku='$kode_buku', 
    isbn='$isbn', judul='$judul', pengarang='$pengarang', tahun='$tahun', penerbit='$penerbit', status='$status'
    where kode_buku='$kodebuku_lama'");
    if($query){
        return true;
    }else{
        return false;
    }
}

function delete_buku($kode_buku){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "delete from tbl_buku where kode_buku='$kode_buku'");
    if($query){
        return true;
    }else{
        return false;
    }
}
?>