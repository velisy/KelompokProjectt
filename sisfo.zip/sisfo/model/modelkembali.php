<?php
include_once("./model/db.php");

function read_all_kembali(){
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "select * from tbl_kembali");
    $data = mysqli_fetch_all($query, MYSQLI_ASSOC);
    return $data;
}

function read_single_kembali($id_kembali){
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "select * from tbl_kembali WHERE id_kembali='$id_kembali'");
    $data = mysqli_fetch_array($query);
    return $data;
}

function save_new_kembali($id_kembali, $id_pinjam, $tgl_kembali, $denda){
    $koneksi = open_koneksi();

    $cek = mysqli_query($koneksi, "select * from tbl_kembali WHERE id_kembali='$id_kembali'");
    if(mysqli_num_rows($cek) > 0){
        return false;
    }

    $query = mysqli_query($koneksi, "INSERT INTO tbl_kembali (id_kembali, id_pinjam, tgl_kembali, denda)
        VALUES ('$id_kembali', '$id_pinjam', '$tgl_kembali', '$denda')");

    if($query){
        mysqli_query($koneksi, "UPDATE tbl_buku 
            SET status='TERSEDIA' 
            WHERE kode_buku = (
                select kode_buku from tbl_pinjam WHERE id_pinjam = '$id_pinjam'
            )");
        return true;
    } else {
        return false;
    }
}

function save_edit_kembali($id_kembali, $id_pinjam, $tgl_kembali, $denda, $idkembali_lama){
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "UPDATE tbl_kembali SET 
        id_kembali='$id_kembali', 
        tgl_kembali='$tgl_kembali', 
        id_pinjam='$id_pinjam', 
        denda='$denda' 
        WHERE id_kembali='$idkembali_lama'");
    return $query ? true : false;
}

function delete_kembali($id_kembali){
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "DELETE from tbl_kembali WHERE id_kembali='$id_kembali'");
    return $query ? true : false;
}
?>
