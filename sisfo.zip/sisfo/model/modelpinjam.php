<?php
include_once("./model/db.php");

function read_all_pinjam(){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_pinjam");
    $data = mysqli_fetch_all($query,MYSQLI_ASSOC);
    return $data;
}
function read_belum_dikembalikan() {
    $koneksi = open_koneksi();
    $query = mysqli_query($koneksi, "
        SELECT * FROM tbl_pinjam 
        WHERE id_pinjam NOT IN (SELECT id_pinjam FROM tbl_kembali)
    ");
    $data = mysqli_fetch_all($query, MYSQLI_ASSOC);
    return $data;
}

function read_single_pinjam($id_pinjam){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_pinjam where id_pinjam='$id_pinjam'");
    $data = mysqli_fetch_array($query);
    return $data;
}

function save_new_pinjam($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_pinjam where id_pinjam='$id_pinjam'");
    if(mysqli_num_rows($query) > 0){
        return false;
    }

    $query = mysqli_query($koneksi, "insert into tbl_pinjam (id_pinjam, tgl_pinjam, kode_buku, npm, deadline)
    values('$id_pinjam', '$tgl_pinjam', '$kode_buku', '$npm', '$deadline')");
    if($query){
        return true;
    }else{
        return false;
    }
}

function save_edit($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline, $idpinjam_lama){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "UPDATE tbl_pinjam SET id_pinjam='$id_pinjam', 
    tgl_pinjam='$tgl_pinjam', kode_buku='$kode_buku', npm='$npm', deadline='$deadline',
    where id_pinjam='$idpinjam_lama'");
    if($query){
        return true;
    }else{
        return false;
    }
}

function delete($id_pinjam){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "delete from tbl_pinjam where id_pinjam='$id_pinjam'");
    if($query){
        return true;
    }else{
        return false;
    }
}
?>