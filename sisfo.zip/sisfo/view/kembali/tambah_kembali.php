<?php 
include('./view/layout/header.php');
include('./model/modelpinjam.php');
$pinjaman = read_belum_dikembalikan();
?>

<div class="row">
    <div class="col-lg-6">
        <h4 class="mb-3">Pengembalian</h4>
        <div class="card shadow">
            <div class="card-header">Tambah Pengembalian</div>
            <div class="card-body">
                <form action="index.php?modul=kembali&proses=proses_tambah" method="post" id="form-kembali">
                    <div class="form-group mb-2">
                        <label>ID Kembali:</label>
                        <input type="text" name="id_kembali" class="form-control" required>
                    </div>
                    <div class="form-group mb-2">
                        <label>ID Pinjam:</label>
                        <select name="id_pinjam" class="form-control" required>
                            <option value="">Pilih ID Pinjam</option>
                            <?php foreach ($pinjaman as $pinjam): ?>
                                <option value="<?= $pinjam['id_pinjam'] ?>" data-deadline="<?= $pinjam['deadline'] ?>">
                                    <?= $pinjam['id_pinjam'] ?> - <?= $pinjam['kode_buku'] ?> (<?= $pinjam['npm'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mb-2">
                        <label>Tanggal Kembali:</label>
                        <input type="date" name="tgl_kembali" id="tgl_kembali" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="form-group mb-2">
                        <label>Denda (Rp):</label>
                        <input type="text" name="denda" id="denda" class="form-control" readonly>
                    </div>
                    <input type="submit" value="Simpan" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
</div>

<script src="./view/kembali/script.js"></script>
<style>
   
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f5e1da;
    color: #5a3e36;
    margin: 0;
    padding: 0;
}
header, footer {
    background-color: #f9c6d0;
    padding: 20px;
    text-align: center;
    color: #5a3e36;
    border-bottom: 3px solid #e89cae;
}
main {
    background-color: #ffffffd9;
    max-width: 800px;
    margin: 30px auto;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(90, 62, 54, 0.1);
}
h1, h2 {
    color: #c66d84;
    text-align: center;
}
.card {
    background-color: #fff9f9;
    border: 1px solid #f9c6d0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 6px rgba(100, 80, 80, 0.1);
    transition: transform 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
}

button {
    background-color: #e89cae;
    color: white;
    border: none;
    padding: 10px 18px;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}
button:hover {
    background-color: #cc7f95;
    transform: scale(1.05);
}
input[type="text"], input[type="number"] {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    margin-bottom: 15px;
    border: 1px solid #d8a8a2;
    border-radius: 6px;
    background-color: #fffaf9;
    color: #5a3e36;
}
footer {
    border-top: 3px solid #e89cae;
    margin-top: 30px;

}
</style>
<?php include('./view/layout/footer.php'); ?>