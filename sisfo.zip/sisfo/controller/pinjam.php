<?php
include("./model/modelpinjam.php");


function index() {
    $data_pinjam = read_all_pinjam();
    include("./view/pinjam/data_pinjam.php");
}

function tambah() {
    include("./view/pinjam/tambah_pinjam.php");
}

function proses_tambah() {
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $kode_buku = $_POST['kode_buku'];
    $npm = $_POST['npm'];
    $deadline = $_POST['deadline'];

    if(save_new_pinjam($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dipinjam!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    mysqli_query(open_koneksi(), "UPDATE tbl_buku SET status='DIPINJAM' WHERE kode_buku='$kode_buku'");

    include("./view/pinjam/tambah_pinjam.php");
}

function ubah() {
    $id_pinjam = $_GET['id_pinjam'];

    $data_pinjam = read_single_pinjam($id_pinjam);

    include("./view/pinjam/ubah_pinjam.php");
}

function proses_ubah() {
    $idpinjam_lama = $_POST['idpinjam_lama'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $kode_buku = $_POST['kode_buku'];
    $npm = $_POST['npm'];
    $deadline = $_POST['deadline'];

    if(save_edit($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline, $idpinjam_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Anggota berhasil diubah!";
        $data_pinjam = read_single_pinjam($id_pinjam);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_pinjam = read_single_pinjam($idpinjam_lama);
    }
    
    include("./view/pinjam/ubah_pinjam.php");
}

function proses_hapus() {
    $id_pinjam = $_GET['id_pinjam'];

    if(delete($id_pinjam)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dikembalikan!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>