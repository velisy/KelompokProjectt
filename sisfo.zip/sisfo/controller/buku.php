<?php
include("./model/modelbuku.php");


function index() {
    $data_buku = read_all_buku();
    include("./view/buku/data_buku.php");
}

function tambah() {
    include("./view/buku/tambah_buku.php");
}

function proses_tambah() {
    $kode_buku = $_POST['kode_buku'];
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $tahun = $_POST['tahun'];
    $penerbit = $_POST['penerbit'];
    $status = $_POST['status'];

    if(save_new_buku($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit, $status)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil ditambah!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }

    include("./view/buku/tambah_buku.php");
}

function ubah() {
    $kode_buku = $_GET['kode_buku'];

    $data_buku = read_single_buku($kode_buku);

    include("./view/buku/ubah_buku.php");
}

function proses_ubah() {
    $kodebuku_lama = $_POST['kodebuku_lama'];
    $kode_buku = $_POST['kode_buku'];
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $tahun = $_POST['tahun'];
    $penerbit = $_POST['penerbit'];
    $status = $_POST['status'];

    if(save_edit_buku($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit, $status, $kodebuku_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil diubah!";
        $data_buku = read_single_buku($kode_buku);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_buku = read_single_buku($kodebuku_lama);
    }
    
    include("./view/buku/ubah_buku.php");
}

function proses_hapus() {
    $kode_buku = $_GET['kode_buku'];

    if(delete($kode_buku)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dihapus!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>