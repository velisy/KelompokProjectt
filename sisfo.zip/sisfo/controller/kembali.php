<?php
include("./model/modelkembali.php");


function index() {
    $data_kembali = read_all_kembali();
    include("./view/kembali/data_kembali.php");
}

function tambah() {
    include("./view/kembali/tambah_kembali.php");
}

function proses_tambah() {
    $id_kembali = $_POST['id_kembali'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $denda = $_POST['denda'];

    if(save_new_kembali($id_kembali, $id_pinjam, $tgl_kembali, $denda)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dikembalikan!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }

    include("./view/kembali/tambah_kembali.php");
}

function ubah() {
    $id_kembali = $_GET['id_kembali'];

    $data_kembali = read_single_kembali($id_kembali);

    include("./view/kembali/ubah_kembali.php");
}

function proses_ubah() {
    $idkembali_lama = $_POST['id_kembali'];
    $id_kembali = $_POST['id_kembali'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $denda = $_POST['denda'];

    if(save_edit_kembali($id_kembali, $id_pinjam, $tgl_kembali, $denda, $idkembali_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dikembalikan";
        $data_kembali = read_single_kembali($id_kembali);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_kembali = read_single_kembali($idkembali_lama);
    }
    
    include("./view/kembali/ubah_kembali.php");
}

function proses_hapus() {
    $id_kembali = $_GET['id_kembali'];

    if(delete($id_kembali)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku telah dikembalikan!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>