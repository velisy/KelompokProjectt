<?php
include("./model/user.php");

function index() {
    include("./view/dashboard.php");
}
?>