<?php
include('./model/db.php');

function read_all(){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_kembali");
    $data = mysqli_fetch_all($query,MYSQLI_ASSOC);
    return $data;
}

function read_single($id_kembali){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_kembali where id_kembali='$id_kembali'");
    $data = mysqli_fetch_array($query);
    return $data;
}

function save_new($id_kembali, $id_pinjam, $tgl_kembali, $denda, $status){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "insert into tbl_kembali
    (id_kembali, id_pinjam, tgl_kembali, denda, status)
    values('$id_kembali', '$id_pinjam', '$tgl_kembali', '$denda', '$status')");
    if($query){
        return true;
    }else{
        return false;
    }
}

function save_edit($id_kembali, $id_pinjam, $tgl_kembali, $denda, $status) {
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "update tbl_kembali set id_kembali='$id_kembali', 
    id_pinjam='$id_pinjam', tgl_kembali='$tgl_kembali', denda='$denda', status='$status',
    where id_kembali='$id_kembali'");
    if($query){
        return true;
    }else{
        return false;
    }
}

function delete($id_kembali){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "delete from tbl_kembali where id_kembali='$id_kembali'");
    if($query){
        return true;
    }else{
        return false;
    }
}
?>