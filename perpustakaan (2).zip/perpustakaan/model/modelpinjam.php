<?php
include("./model/db.php");

function read_all(){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_pinjam");
    $data = mysqli_fetch_all($query,MYSQLI_ASSOC);
    return $data;
}

function read_single($id_pinjam){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "select * from tbl_pinjam where id_pinjam='$id_pinjam'");
    $data = mysqli_fetch_array($query);
    return $data;
}

function save_new($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline){
    $koneksi = open_koneksi();

    $query = mysqli_query($koneksi, "insert into tbl_pinjam (id_pinjam, tgl_pinjam, kode_buku, npm, deadline)
    values('$id_pinjam', '$tgl_pinjam', '$kode_buku', '$npm', '$deadline')");
    if($query){
        mysqli_query($koneksi, "update tbl_buku set status='Dipinjam' where kode_buku='$kode_buku'");
        return true;
    }else{
        return false;
    }
}

function save_edit($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline, $id_lama){
    $koneksi = open_koneksi();

    $q = mysqli_query($koneksi, "select kode_buku from tbl_pinjam where id_pinjam='$id_lama'");
    $kode_lama = mysqli_fetch_assoc($q)['kode_buku'];

    $query = mysqli_query($koneksi, "update tbl_pinjam set id_pinjam='$id_pinjam', 
    tgl_pinjam='$tgl_pinjam', kode_buku='$kode_buku', npm='$npm', deadline='$deadline'
    where id_pinjam='$id_lama'");
    if($query){
        if($kode_lama != $kode_buku){
            mysqli_query($koneksi, "update tbl_buku set status='Tersedia' where kode_buku='$kode_lama'");
            mysqli_query($koneksi, "update tbl_buku set status='Dipinjam' where kode_buku='$kode_buku'");
        }
        return true;
    }else{
        return false;
    }
}

function delete($id_pinjam){
    $koneksi = open_koneksi();

    $ambil_kode = mysqli_query($koneksi, "select kode_buku from tbl_pinjam where id_pinjam='$id_pinjam'");
    $update = mysqli_fetch_assoc($ambil_kode);
    $kode_buku = $update['kode_buku'];

    mysqli_query($koneksi, "update tbl_buku set status='Tersedia' where kode_buku='$kode_buku'");

    $query = mysqli_query($koneksi, "delete from tbl_pinjam where id_pinjam='$id_pinjam'");
    if($query){
        return true;
    }else{
        return false;
    }
}
?>