<?php
include('./model/modelbuku.php');

function index() {
    $data_buku = read_all();
    include("./view/buku/data_buku.php");
}

function tambah() {
    include("./view/buku/tambah_buku.php");
}

function proses_tambah() {
    $koneksi = open_koneksi();

    $kode_buku = $_POST['kode_buku'];
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $tahun = $_POST['tahun'];
    $penerbit = $_POST['penerbit'];

    if(save_new($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil ditambah!";
        mysqli_query($koneksi, "update tbl_buku set status='Tersedia' where kode_buku='$kode_buku'");
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }

    include("./view/buku/tambah_buku.php");
}

function ubah() {
    $kode_buku = $_GET['kode_buku'];

    $data_buku = read_single($kode_buku);

    include("./view/buku/ubah_buku.php");
}

function proses_ubah() {
    $kode_lama = $_POST['kode_lama'];
    $kode_buku = $_POST['kode_buku'];
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $tahun = $_POST['tahun'];
    $penerbit = $_POST['penerbit'];

    if(save_edit($kode_buku, $isbn, $judul, $pengarang, $tahun, $penerbit, $kode_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil diubah!";
        $data_buku = read_single($kode_buku);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_buku = read_single($kode_lama);
    }
    
    include("./view/buku/ubah_buku.php");
}

function proses_hapus() {
    $kode_buku = $_GET['kode_buku'];

    if(delete($kode_buku)){
        $_SESSION["SUCCESS_SISTEM"] = "Buku berhasil dihapus!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>