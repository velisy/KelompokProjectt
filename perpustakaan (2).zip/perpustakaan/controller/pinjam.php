<?php
include("./model/modelpinjam.php");

function index() {
    $data_pinjam = read_all();
    include("./view/pinjam/data_pinjam.php");
}

function tambah() {
    include("./view/pinjam/tambah_pinjam.php");
}

function proses_tambah() {
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $kode_buku = $_POST['kode_buku'];
    $npm = $_POST['npm'];
    $deadline = $_POST['deadline'];

    if(save_new($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline)){
        $_SESSION["SUCCESS_SISTEM"] = "Peminjaman berhasil ditambah!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }

    include("./view/pinjam/tambah_pinjam.php");
}

function ubah() {
    $id_pinjam = $_GET['id_pinjam'];

    $data_pinjam = read_single($id_pinjam);

    include("./view/pinjam/ubah_pinjam.php");
}

function proses_ubah() {
    $id_lama = $_POST['id_lama'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $kode_buku = $_POST['kode_buku'];
    $npm = $_POST['npm'];
    $deadline = $_POST['deadline'];

    if(save_edit($id_pinjam, $tgl_pinjam, $kode_buku, $npm, $deadline, $id_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Peminjaman berhasil diubah!";
        $data_pinjam = read_single($id_pinjam);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_pinjam = read_single($id_lama);
    }
    
    include("./view/pinjam/ubah_pinjam.php");
}

function proses_hapus() {
    $id_pinjam = $_GET['id_pinjam'];

    if(delete($id_pinjam)){
        $_SESSION["SUCCESS_SISTEM"] = "Peminjaman berhasil dihapus!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>