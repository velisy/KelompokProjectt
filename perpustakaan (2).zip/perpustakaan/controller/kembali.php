<?php
include("./model/modelkembali.php");

function index() {
    $data_pinjam = read_all();
    include("./view/kembali/data_kembali.php");
}

function tambah() {
    include("./view/kembali/tambah_kembali.php");
}

function proses_tambah() {
    $id_kembali = $_POST['id_kembali'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $denda = $_POST['denda'];
    $status = $_POST['status'];

    if(save_new($id_kembali,  $id_pinjam,  $tgl_kembali,  $denda, $status)){
        $_SESSION["SUCCESS_SISTEM"] = "kembali berhasil ditambah!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }

    include("./view/kembali/tambah_kembali.php");
}

function ubah() {
    $id_kembali = $_GET['id_kembali'];

    $data_kembali = read_single($id_kembali);

    include("./view/kembali/ubah_kembali.php");
}

function proses_ubah() {
    $id_lama = $_POST['id_lama'];
    $id_kembali = $_POST['id_kembali'];
    $id_pinjam = $_POST['id_pinjam'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $denda = $_POST['denda'];
    $status = $_POST['status'];

    if(save_edit($id_kembali, $id_pinjam, $tgl_kembali, $denda, $status, $id_lama)){
        $_SESSION["SUCCESS_SISTEM"] = "Kembali berhasil diubah!";
        $data_kembali = read_single($id_kembali);
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
        $data_kembali = read_single($id_lama);
    }
    
    include("./view/kembali/ubah_kembali.php");
}

function proses_hapus() {
    $id_kembali = $_GET['id_kembali'];

    if(delete($id_kembali)){
        $_SESSION["SUCCESS_SISTEM"] = "Kembali berhasil dihapus!";
    }else{
        $_SESSION["ERROR_SISTEM"] = "Proses gagal!";
    }
    
    index();
}
?>