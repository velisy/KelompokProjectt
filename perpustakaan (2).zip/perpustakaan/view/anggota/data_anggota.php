<?php include('./view/layout/header.php'); ?>

<div class="row">
    <div class="col-lg-12">
        <h4 class="mb-3">Anggota</h4>
        <div class="card">
            <div class="card-header">
                <a href="index.php?modul=anggota&proses=tambah" class="btn btn-primary">Tambah Anggota</a>
            </div>
            <div class="card-body">
                <?php
                if(isset($_SESSION["ERROR_SISTEM"])){
                    echo '<div class="alert alert-danger" role="alert">'.$_SESSION["ERROR_SISTEM"].'</div>';
                    unset($_SESSION["ERROR_SISTEM"]);
                }

                if(isset($_SESSION["SUCCESS_SISTEM"])){
                    echo '<div class="alert alert-success" role="alert">'.$_SESSION["SUCCESS_SISTEM"].'</div>';
                    unset($_SESSION["SUCCESS_SISTEM"]);
                }
                ?>
                <table class="table table-bordered table-sm">
                    <thead>
                        <th>No.</th>
                        <th>NPM</th>
                        <th>Nama</th>
                        <th>Jurusan</th>
                        <th>No Telp</th>
                        <th>Email</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach($data_anggota as $anggota): ?>
                        <tr>
                            <td><?=$i?></td>
                            <td><?=$anggota['npm']?></td>
                            <td><?=$anggota['nama']?></td>
                            <td><?=$anggota['jurusan']?></td>
                            <td><?=$anggota['no_telp']?></td>
                            <td><?=$anggota['email']?></td>
                            <td>
                                <a href="index.php?modul=anggota&proses=ubah&npm=<?=$anggota['npm']?>" class="btn btn-sm btn-success">Edit</a> | <a href="index.php?modul=anggota&proses=proses_hapus&npm=<?=$anggota['npm']?>" class="btn btn-sm btn-danger">Hapus</a>
                            </td>
                        </tr>
                        <?php 
                        $i+=1;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>

<style>
   
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}


body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f5e1da;
    color: #5a3e36;
    margin: 0;
    padding: 0;
}
header, footer {
    background-color: #f9c6d0;
    padding: 20px;
    text-align: center;
    color: #5a3e36;
    border-bottom: 3px solid #e89cae;
}
main {
    background-color: #ffffffd9;
    max-width: 800px;
    margin: 30px auto;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(90, 62, 54, 0.1);
}
h1, h2 {
    color: #c66d84;
    text-align: center;
}
.card {
    background-color: #fff9f9;
    border: 1px solid #f9c6d0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 6px rgba(100, 80, 80, 0.1);
    transition: transform 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
}

button {
    background-color: #e89cae;
    color: white;
    border: none;
    padding: 10px 18px;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}
button:hover {
    background-color: #cc7f95;
    transform: scale(1.05);
}
input[type="text"], input[type="number"] {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    margin-bottom: 15px;
    border: 1px solid #d8a8a2;
    border-radius: 6px;
    background-color: #fffaf9;
    color: #5a3e36;
}
footer {
    border-top: 3px solid #e89cae;
    margin-top: 30px;

}
</style>
<?php include('./view/layout/footer.php'); ?>