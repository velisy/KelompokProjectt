<!DOCTYPE html>
<html class="h-100">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login</title>
        <link rel="stylesheet" href="./addon/bootstrap/css/bootstrap.min.css">
        <script src="./addon/jquery.js"></script>
        <script src="./addon/bootstrap/js/bootstrap.bundle.min.js"></script>
    </head>
    <body class="h-100">
        <div class="container h-100">
            <div class="row h-100 d-flex justify-content-center align-items-center">
                <div class="col-lg-4">
                    <div class="card shadow">
                        <div class="card-body">
                            <h4 class="mb-3 py-3 border-bottom">Login</h4>
                            <?php
                            if(isset($_SESSION["ERROR_SISTEM"])){
                                echo '<div class="alert alert-danger" role="alert">'.$_SESSION["ERROR_SISTEM"].'</div>';
                                unset($_SESSION["ERROR_SISTEM"]);
                            }
                            ?>
                            <div class="fst-italic mb-3">Silahkan login untuk masuk ke dalam sistem</div>
                            <form action="index.php?modul=auth&proses=vlogin" method="post">
                                <div class="form-group mb-3">
                                    <label>Username :</label>
                                    <input type="text" name="username" class="form-control">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Password :</label>
                                    <input type="password" name="password" class="form-control">
                                </div>
                                <hr/>
                                 <style>
                                    /* Reset basic style */
                                * {
                                    margin: 0;
                                    padding: 0;
                                    box-sizing: border-box;
                                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                }

                                body {
                                    background-image: url(foto5.WEBP);
                                    height: 100vh;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                }

                                .card {
                                    background-color: grey;
                                    width: 350px;
                                    padding: 30px;
                                    border-radius: 10px;
                                    box-shadow: 0px 4px 20px rgba(190, 126, 162, 0.1);
                                    transition: all 0.3s ease;
                                }

                                .card h3 {
                                    text-align: center;
                                    margin-bottom: 10px;
                                    font-weight: 600;
                                    color: #216, rgb(214, 132, 65);
                                }

                                .card hr {
                                    margin-bottom: 20px;
                                }

                                .card p {
                                    font-size: 0.9rem;
                                    color: #666;
                                    margin-bottom: 20px;
                                    text-align: center;
                                    font-style: italic;
                                }

                                .form-group {
                                    margin-bottom: 15px;
                                }

                                label {
                                    font-size: 0.9rem;
                                    color: #333;
                                    display: block;
                                    margin-bottom: 5px;
                                }

                                input[type="text"],
                                input[type="password"] {
                                    width: 100%;
                                    padding: 10px 12px;
                                    border-radius: 6px;
                                    border: 1px solid #ccc;
                                    font-size: 0.95rem;
                                    transition: border-color 0.3s;
                                }

                                input[type="text"]:focus,
                                input[type="password"]:focus {
                                    border-color:rgb(214, 132, 65);
                                    outline: none;
                                }

                                button {
                                    width: 100%;
                                    background-color:rgb(94, 192, 55);
                                    border: none;
                                    padding: 12px;
                                    font-size: 1rem;
                                    color: white;
                                    border-radius: 6px;
                                    cursor: pointer;
                                    transition: background-color 0.3s;
                                }

                                button:hover {
                                    background-color:rgb(128, 142, 182);
                                }
                                
                                .card {
                                    background-color:rgb(228, 157, 180);
                                    border: 1px solid #ffccdd;
                                    animation: floatCard 3s ease-in-out infinite alternate;
                                }

                                input[type="text"], input[type="number"] {
                                    padding: 8px;
                                    border: 1px solid #ff99cc;
                                    border-radius: 5px;
                                    margin-top: 5px;
                                    width: 100%;
                                }

                                footer {
                                    border-top: 4px solid #ff99cc;
                                    animation: slideUp 1s ease-out;
                                }

                                @keyframes fadeIn {
                                    from {opacity: 0;}
                                    to {opacity: 4;}
                                }

                                @keyframes slideDown {
                                    from {transform: translateY(-100%);}
                                    to {transform: translateY(0);}
                                }

                                @keyframes slideUp {
                                    from {transform: translateY(100%);}
                                    to {transform: translateY(0);}
                                }

                                @keyframes floatCard {
                                    from {transform: translateY(0);}
                                    to {transform: translateY(-10px);}

                                }
                                </style>
                                <input type="submit" value="Login" class="btn btn-primary w-100">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>