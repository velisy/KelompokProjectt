document.addEventListener("DOMContentLoaded", () => {
    const select = document.querySelector("select[name='id_pinjam']");
    const tglKembali = document.getElementById("tgl_kembali");
    const dendaInput = document.getElementById("denda");

    if (select) {
        select.addEventListener("change", updateDenda);
    }
    if (tglKembali) {
        tglKembali.addEventListener("change", updateDenda);
    }

    function updateDenda() {
        if (!select || !tglKembali || !dendaInput) return;

        const deadlineStr = select.options[select.selectedIndex]?.getAttribute("data-deadline");
        if (!deadlineStr || !tglKembali.value) {
            dendaInput.value = 0;
            return;
        }

        const deadlineDate = new Date(deadlineStr);
        const kembaliDate = new Date(tglKembali.value);

        // Hitung selisih hari
        const millisPerDay = 1000 * 60 * 60 * 24;
        const selisihHari = Math.floor((kembaliDate - deadlineDate) / millisPerDay);

        // Hitung denda (Rp.1000 per hari keterlambatan)
        dendaInput.value = selisihHari > 0 ? selisihHari * 1000 : 0;
    }
});
